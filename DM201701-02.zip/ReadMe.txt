The report file name is "Explore the data.ipynb"

For data prediction, the code is saved in "data prediction.ipynb"

We put our dataset on dropbox cloud storage, therefor your pc must online whe running jupyter notebook, if not, you can access the dataset offline with the "Dataset" folder, "train,csv" and "test.csv".

All file can be access from github https://github.com/zisean/dmhouseprice